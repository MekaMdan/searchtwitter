Passos para usar a aplicação:

Insira as chaves de acesso à API do twitter no arquivo system/keys.txt
Atualize o arquivo data/tags.txt com as tags de notícias de seu interesse
Execute le_stream_tuites.py
Obtenha para análise o fluxo de tuites nos arquivos tuites.json e tuites_backup_*.json
 

